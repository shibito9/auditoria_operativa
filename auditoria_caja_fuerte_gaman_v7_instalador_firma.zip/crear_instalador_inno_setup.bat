@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Crear Instalador - GAMAN Auditoria Caja Fuerte

echo ==========================================
echo   CREAR INSTALADOR - GAMAN AUDITORIA CAJA FUERTE
echo   Desarrollado por SANTIAGO AGUDELO - GAMAN -
echo ==========================================
echo.

if not exist "dist\GAMAN_Auditoria_Caja_Fuerte\GAMAN_Auditoria_Caja_Fuerte.exe" (
    echo Primero debes ejecutar crear_exe_portable.bat
    pause
    exit /b 1
)

set ISCC="C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="C:\Program Files\Inno Setup 6\ISCC.exe"

if not exist %ISCC% (
    echo No encontre Inno Setup 6 instalado.
    echo Descargalo e instalalo desde: https://jrsoftware.org/isdl.php
    echo Luego vuelve a ejecutar este archivo.
    pause
    exit /b 1
)

%ISCC% "instalador_gaman_auditoria_caja_fuerte.iss"

if errorlevel 1 (
    echo.
    echo ERROR: No se pudo compilar el instalador.
    pause
    exit /b 1
)

echo.
echo LISTO. El instalador quedo en la carpeta Output.
pause
